package com.cauamariz.consumindoapi;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface Api {
    @GET("{cep}/json")
    Call<CEP> getCep(@Path("cep") String cep);
}
